package net.arna.jcraft.client.rendering.api;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.ArrayList;
import java.util.List;

public class PostProcessHandler {
    private static final List<PostProcessor> instances = new ArrayList<>();

    private static boolean didCopyDepth = false;

    /**
     * Add an {@link PostProcessor} for it to be handled automatically.
     * IMPORTANT: processors has to be added in the right order!!!
     * There's no way of getting an instance, so you need to keep the instance yourself.
     */
    public static void addInstance(final PostProcessor instance) {
        instances.add(instance);
    }

    public static void copyDepthBuffer() {
        if (didCopyDepth) {
            return;
        }
        instances.forEach(PostProcessor::copyDepthBuffer);
        didCopyDepth = true;
    }

    public static void resize(final int width, final int height) {
        instances.forEach(i -> i.resize(width, height));
    }

    public static void renderLast(final PoseStack matrices) {
        copyDepthBuffer(); // copy the depth buffer if the mixin didn't trigger

        PostProcessor.viewModelStack = matrices;
        instances.forEach(PostProcessor::applyPostProcess);

        didCopyDepth = false; // reset for next frame
    }
}
