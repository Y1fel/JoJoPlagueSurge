package net.arna.jcraft.common.attack.moves.shared;

import com.mojang.datafixers.kinds.App;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import lombok.NonNull;
import net.arna.jcraft.api.attack.IAttacker;
import net.arna.jcraft.api.attack.MoveType;
import net.arna.jcraft.api.attack.moves.AbstractMove;
import net.arna.jcraft.api.stand.StandEntity;
import net.minecraft.world.entity.LivingEntity;

import java.util.Set;

public final class StandbyDeactivationMove<A extends IAttacker<? extends A, ?>> extends AbstractMove<StandbyDeactivationMove<A>, A> {

    public StandbyDeactivationMove(int cooldown, int windup, int duration, float moveDistance) {
        super(cooldown, windup, duration, moveDistance);
    }

    @Override
    public @NonNull MoveType<StandbyDeactivationMove<A>> getMoveType() {
        return Type.INSTANCE.cast();
    }

    @Override
    public @NonNull Set<LivingEntity> perform(A attacker, LivingEntity user) {
        if (attacker instanceof StandEntity<?,?> stand) {
            stand.setStandby(false);
        }
        return Set.of();
    }

    @Override
    protected @NonNull StandbyDeactivationMove<A> getThis() {
        return this;
    }

    @Override
    public @NonNull StandbyDeactivationMove<A> copy() {
        return copyExtras(new StandbyDeactivationMove<>(getCooldown(), getWindup(), getDuration(), getMoveDistance()));
    }

    public static class Type extends AbstractMove.Type<StandbyDeactivationMove<?>> {
        public static final Type INSTANCE = new Type();

        @Override
        protected @NonNull App<RecordCodecBuilder.Mu<StandbyDeactivationMove<?>>, StandbyDeactivationMove<?>> buildCodec(RecordCodecBuilder.Instance<StandbyDeactivationMove<?>> instance) {
            return instance.group(cooldown(), windup(), duration(), moveDistance()).apply(instance, StandbyDeactivationMove::new);
        }
    }
}
