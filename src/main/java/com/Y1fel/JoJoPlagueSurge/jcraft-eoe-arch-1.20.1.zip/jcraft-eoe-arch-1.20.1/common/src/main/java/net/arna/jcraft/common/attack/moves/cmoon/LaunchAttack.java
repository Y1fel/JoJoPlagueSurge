package net.arna.jcraft.common.attack.moves.cmoon;

import com.mojang.datafixers.kinds.App;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import lombok.NonNull;
import net.arna.jcraft.api.attack.MoveType;
import net.arna.jcraft.api.attack.moves.AbstractSimpleAttack;
import net.arna.jcraft.common.entity.projectile.BlockProjectile;
import net.arna.jcraft.common.entity.stand.CMoonEntity;
import net.arna.jcraft.common.gravity.api.GravityChangerAPI;
import net.arna.jcraft.common.util.JParticleType;
import net.minecraft.core.Vec3i;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public final class LaunchAttack extends AbstractSimpleAttack<LaunchAttack, CMoonEntity> {
    public LaunchAttack(final int cooldown, final int windup, final int duration, final float moveDistance, final float damage, final int stun,
                        final float hitboxSize, final float knockback, final float offset) {
        super(cooldown, windup, duration, moveDistance, damage, stun, hitboxSize, knockback, offset);
        ranged = true;
        hitSpark = JParticleType.HIT_SPARK_2;
    }

    @Override
    public @NotNull MoveType<LaunchAttack> getMoveType() {
        return Type.INSTANCE;
    }

    @Override
    public @NonNull Set<LivingEntity> perform(final CMoonEntity attacker, final LivingEntity user) {
        final Set<LivingEntity> targets = super.perform(attacker, user);

        final BlockProjectile block = new BlockProjectile(attacker.level());
        final BlockState steppingState = attacker.getBlockStateOn();
        if (steppingState.isAir() || !steppingState.canOcclude()) {
            block.setBlockStack(Items.STONE.getDefaultInstance());
        } else {
            block.setBlockStack(steppingState.getBlock().asItem().getDefaultInstance());
        }

        final Vec3i hoverDir = GravityChangerAPI.getGravityDirection(user).getNormal().multiply(-1);

        block.setMaster(user);
        block.moveTo(attacker.getX() + hoverDir.getX() * 1.5, attacker.getY() + hoverDir.getY() * 1.5,
                attacker.getZ() + hoverDir.getZ() * 1.5, attacker.getYRot(), attacker.getXRot());
        block.setDeltaMovement(hoverDir.getX() * 0.4, hoverDir.getY() * 0.4, hoverDir.getZ() * 0.4);
        attacker.level().addFreshEntity(block);

        return targets;
    }

    @Override
    protected @NonNull LaunchAttack getThis() {
        return this;
    }

    @Override
    public @NonNull LaunchAttack copy() {
        return copyExtras(new LaunchAttack(getCooldown(), getWindup(), getDuration(), getMoveDistance(), getDamage(),
                getStun(), getHitboxSize(), getKnockback(), getOffset()));
    }

    public static class Type extends AbstractSimpleAttack.Type<LaunchAttack> {
        public static final Type INSTANCE = new Type();

        @Override
        protected @NotNull App<RecordCodecBuilder.Mu<LaunchAttack>, LaunchAttack> buildCodec(RecordCodecBuilder.Instance<LaunchAttack> instance) {
            return attackDefault(instance, LaunchAttack::new);
        }
    }
}
